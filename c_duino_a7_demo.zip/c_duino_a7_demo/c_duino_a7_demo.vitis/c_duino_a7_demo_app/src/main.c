/*-----------------------------------------------------------------------
 * MODIFICATION HISTORY
 * Ver   Who       Date       Changes
 * ----- --------- ---------- --------------------------------------------
 * 0.01  MADUINOS  2024/03/01 draft
 *
 -----------------------------------------------------------------------*/
#include "xstatus.h"
#include "xparameters.h"
#include "xsysmon.h"
#include "xgpio.h"
#include "xil_printf.h"
#include "sleep.h"

XGpio GpioRgb;
XGpio GpioLedBtn;
XGpio GpioPmodJA;
XGpio GpioPmod1;
XGpio GpioPmod2;
XGpio GpioPmod3;
XSysMon SysMonInst;

#define LED_CH  1
#define BTN_CH  2
#define CH_1    1

#define OUTPUT  0x00000000
#define INPUT   0xFFFFFFFF

#define LED_ON  0xFF
#define LED_OFF 0x00

#define RGB_WHITE 0b000
#define RGB_RED 0b011
#define RGB_GREEN 0b101
#define RGB_YELLOW 0b100
#define RGB_CYAN 0b001
#define RGB_MAGENTA 0b010
#define RGB_BLUE 0b110
#define RGB_OFF 0b111

const u32 rgb_colorarray[] = {
    RGB_RED,
    RGB_GREEN,
    RGB_BLUE,
    RGB_MAGENTA,
    RGB_CYAN,
    RGB_YELLOW,
    RGB_WHITE,
    RGB_OFF
};

s32 gpio_init();
s32 xadc_init();
s32 SysMonFractionToInt(float FloatNum);

int main() {
    u32 BtnState;
    u32 LedState;
    u32 BtnCnt = 0;
    u16 VAuxRawData;
    float VAuxData;

    xil_printf("\r\n=== C_DUINO_A7 DEMO START ===\r\n");

    gpio_init();
    xadc_init();

	while (1) {
		BtnState = XGpio_DiscreteRead(&GpioLedBtn, BTN_CH);
        if( BtnState == 0x00000001 ) {
            BtnCnt++;
            if(BtnCnt == 8) {
                BtnCnt = 0;
            }
            //LedState = LED_ON;
            LedState = 1 << BtnCnt;
        }
        else {
            //LedState = LED_OFF;
        }
        xil_printf("RGB State[%d]\r\n", BtnCnt);
        XGpio_DiscreteWrite(&GpioRgb, CH_1, rgb_colorarray[BtnCnt]);
        XGpio_DiscreteWrite(&GpioLedBtn, LED_CH, LedState);
        XGpio_DiscreteWrite(&GpioPmodJA, CH_1, ~LedState);
        XGpio_DiscreteWrite(&GpioPmod1, CH_1, ~LedState);
        XGpio_DiscreteWrite(&GpioPmod2, CH_1, ~LedState);
        XGpio_DiscreteWrite(&GpioPmod3, CH_1, ~LedState);

		VAuxRawData = XSysMon_GetAdcData(&SysMonInst, XSM_CH_AUX_MIN+4); // AUX04
		VAuxData = ((((float)(VAuxRawData))* (3.3f))/65536.0f);
		xil_printf("The VAUX04 is %0d.%03d Volts. \r\n", (int)(VAuxData), SysMonFractionToInt(VAuxData));

		VAuxRawData = XSysMon_GetAdcData(&SysMonInst, XSM_CH_AUX_MIN+12); // AUX12
		VAuxData = ((((float)(VAuxRawData))* (3.3f))/65536.0f);
		xil_printf("The VAUX12 is %0d.%03d Volts. \r\n", (int)(VAuxData), SysMonFractionToInt(VAuxData));

        sleep(1);
	}

	return XST_SUCCESS;
}

s32 gpio_init()
{
	s32 Status;

	Status = XGpio_Initialize(&GpioLedBtn, XPAR_AXI_GPIO_0_DEVICE_ID);
	Status |= XGpio_Initialize(&GpioRgb, XPAR_AXI_GPIO_1_DEVICE_ID);
	Status |= XGpio_Initialize(&GpioPmodJA, XPAR_AXI_GPIO_JA_DEVICE_ID);
	Status |= XGpio_Initialize(&GpioPmod1, XPAR_AXI_GPIO_PMOD1_DEVICE_ID);
	Status |= XGpio_Initialize(&GpioPmod2, XPAR_AXI_GPIO_PMOD2_DEVICE_ID);
	Status |= XGpio_Initialize(&GpioPmod3, XPAR_AXI_GPIO_PMOD3_DEVICE_ID);
	if (Status != XST_SUCCESS) {
		xil_printf("Gpio Initialization Failed\r\n");
		return XST_FAILURE;
	}

	XGpio_SetDataDirection(&GpioRgb, CH_1, OUTPUT);
	XGpio_SetDataDirection(&GpioLedBtn, LED_CH, OUTPUT);
	XGpio_SetDataDirection(&GpioLedBtn, BTN_CH, INPUT);
	XGpio_SetDataDirection(&GpioPmodJA, CH_1, OUTPUT);  // TEST FOR LED
	XGpio_SetDataDirection(&GpioPmod1, CH_1, OUTPUT);   // TEST FOR LED
	XGpio_SetDataDirection(&GpioPmod2, CH_1, OUTPUT);   // TEST FOR LED
	XGpio_SetDataDirection(&GpioPmod3, CH_1, OUTPUT);   // TEST FOR LED

	xil_printf("Gpio Initialization Success\r\n");

	return XST_SUCCESS;
}

s32 xadc_init()
{
	XSysMon_Config *ConfigPtr;

	ConfigPtr = XSysMon_LookupConfig(XPAR_XADC_WIZ_0_DEVICE_ID);
	if (ConfigPtr == NULL) {
		return XST_FAILURE;
	}
	XSysMon_CfgInitialize(&SysMonInst, ConfigPtr, ConfigPtr->BaseAddress);

	xil_printf("Xadc Initialization Success\r\n");

	return XST_SUCCESS;
}

s32 SysMonFractionToInt(float FloatNum)
{
	float Temp;

	Temp = FloatNum;
	if (FloatNum < 0) {
		Temp = -(FloatNum);
	}

	return (((int) ((Temp - (float) ((int) Temp)) * (1000.0f))));
}

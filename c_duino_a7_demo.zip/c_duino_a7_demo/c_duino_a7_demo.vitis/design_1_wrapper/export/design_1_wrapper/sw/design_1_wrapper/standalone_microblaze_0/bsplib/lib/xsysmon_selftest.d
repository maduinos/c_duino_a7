../../../lib/xsysmon_selftest.o: xsysmon_selftest.c xsysmon.h \
 ../../../include/xstatus.h ../../../include/xil_types.h \
 ../../../include/bspconfig.h ../../../include/xparameters.h \
 ../../../include/xil_assert.h xsysmon_hw.h ../../../include/xil_types.h \
 ../../../include/xil_assert.h ../../../include/xil_io.h \
 ../../../include/xil_printf.h ../../../include/xstatus.h \
 ../../../include/mb_interface.h ../../../include/xil_exception.h \
 ../../../include/xparameters.h
xsysmon.h:
../../../include/xstatus.h:
../../../include/xil_types.h:
../../../include/bspconfig.h:
../../../include/xparameters.h:
../../../include/xil_assert.h:
xsysmon_hw.h:
../../../include/xil_types.h:
../../../include/xil_assert.h:
../../../include/xil_io.h:
../../../include/xil_printf.h:
../../../include/xstatus.h:
../../../include/mb_interface.h:
../../../include/xil_exception.h:
../../../include/xparameters.h:

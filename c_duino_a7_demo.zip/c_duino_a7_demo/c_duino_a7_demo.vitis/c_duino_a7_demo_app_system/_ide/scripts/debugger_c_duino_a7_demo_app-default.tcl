# Usage with Vitis IDE:
# In Vitis IDE create a Single Application Debug launch configuration,
# change the debug type to 'Attach to running target' and provide this 
# tcl script in 'Execute Script' option.
# Path of this script: D:\00_vivado_prj\c_duino_a7_demo\c_duino_a7_demo\c_duino_a7_demo.vitis\c_duino_a7_demo_app_system\_ide\scripts\debugger_c_duino_a7_demo_app-default.tcl
# 
# 
# Usage with xsct:
# To debug using xsct, launch xsct and run below command
# source D:\00_vivado_prj\c_duino_a7_demo\c_duino_a7_demo\c_duino_a7_demo.vitis\c_duino_a7_demo_app_system\_ide\scripts\debugger_c_duino_a7_demo_app-default.tcl
# 
connect -url tcp:127.0.0.1:3121
targets -set -filter {jtag_cable_name =~ "Digilent Cmod A7 - 35T 210328BB19A1A" && level==0 && jtag_device_ctx=="jsn-Cmod A7 - 35T-210328BB19A1A-0362d093-0"}
fpga -file D:/00_vivado_prj/c_duino_a7_demo/c_duino_a7_demo/c_duino_a7_demo.vitis/c_duino_a7_demo_app/_ide/bitstream/design_1_wrapper.bit
targets -set -nocase -filter {name =~ "*microblaze*#0" && bscan=="USER2" }
loadhw -hw D:/00_vivado_prj/c_duino_a7_demo/c_duino_a7_demo/c_duino_a7_demo.vitis/design_1_wrapper/export/design_1_wrapper/hw/design_1_wrapper.xsa -regs
configparams mdm-detect-bscan-mask 2
targets -set -nocase -filter {name =~ "*microblaze*#0" && bscan=="USER2" }
rst -system
after 3000
targets -set -nocase -filter {name =~ "*microblaze*#0" && bscan=="USER2" }
dow D:/00_vivado_prj/c_duino_a7_demo/c_duino_a7_demo/c_duino_a7_demo.vitis/c_duino_a7_demo_app/Debug/c_duino_a7_demo_app.elf
targets -set -nocase -filter {name =~ "*microblaze*#0" && bscan=="USER2" }
con
